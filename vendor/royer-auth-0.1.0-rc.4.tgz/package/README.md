# @royer/auth

Private release candidate with two explicit modes over maintained Better Auth 1.7.7 components. Standalone mode keeps credentials and accounts in each app. Central mode provides one Breakthrough account through a dedicated OIDC issuer and consumer adapter. Both retain app-owned IDs, permissions and host-only sessions. The rc.3 additions remain under verification; this document does not approve adoption.

## Server

Install the private tarball and keep it pinned. Configure one instance per app:

```ts
import { createPrivateAuth } from "@royer/auth/server";

export const auth = createPrivateAuth({
  appId: "your-app",
  appName: "Your app",
  baseURL: "https://app.example.com",
  secret: process.env.AUTH_SECRET!,
  database: appDatabase,
  email: {
    sendVerification: async ({ user, url }) => sendEmail(user.email, url),
    sendPasswordReset: async ({ user, url }) => sendEmail(user.email, url),
  },
  companionPage: "/approve",
  // Only when your ingress strips client-supplied copies of this header:
  ipAddress: { headers: ["x-forwarded-for"], trustedProxies: ["198.51.100.0/24"] },
});
```

The proxy range above is an example, not a deployment default. Set the actual ingress range or omit the option. The secret must contain at least 32 characters; supply a cryptographically random secret from your app's secret store. The origin must be exact HTTPS, with HTTP allowed only on loopback for development. Supply real email delivery callbacks in production.

In a Next.js Node route at `app/api/auth/[...all]/route.ts`, export `GET = auth.handler` and `POST = auth.handler`. Forward the incoming Request unchanged. For protected pages and APIs call `await auth.getPrincipal(headers)`. It returns `{ id, name, email, emailVerified }` or null; the app still owns resource authorization. Do not use a browser session object as authorization.

The declared database option is Better Auth's supported database input. The regression suite uses Node 24 `DatabaseSync` from `node:sqlite`. The built-in Kysely adapter was verified with a PostgreSQL 17 pool and two server instances against one isolated test schema. Custom adapters must uphold Better Auth's atomic `incrementOne` and `consumeOne` contracts and database uniqueness; arbitrary adapter portability is not claimed. Use a dedicated database or independently isolated schema per app.

Version 0.1.0-rc.2 adds the required `totpUse` table with a unique key, a cascading user reference and indexed expiry. Apply its schema migration before sending traffic to the new package. For schema setup, use the pinned `better-auth/db/migration` `getMigrations(auth.engine.options)` API, review its migration, and run it in the application's migration process. `engine.options` is exposed for migrations only. Never publish the underlying engine's handler or API: it bypasses this package's browser and assurance policies. The reference app automatically migrates only its disposable local fixture.

## Central accounts

Use `createIdentityIssuer` from `@royer/auth/issuer` for the separate credential, MFA, phone approval and email owner. Its operator IDs are immutable user IDs, configured outside requests. Register confidential clients through its authenticated `registerClient` method with exact HTTPS callback and logout addresses. The deployable Preview-only application and configuration packet are in `apps/accounts`.

Use `createFederatedAuth` from `@royer/auth/federation` in each consumer. It accepts app identity, exact base URL, independent secret, PostgreSQL Pool, exact `issuerURL`, client ID and client secret. Mount only its public handler; call `getPrincipal` for protected reads. The consumer owns its database, stable principal IDs, data and authorization. It never receives central passwords or delivers central recovery mail.

For a protected issuer, optional `issuerRequestHeaders` supplies fresh server-only headers per outgoing issuer request. It must return a nonempty string record. It cannot replace cookie, authorization or protocol/transport headers; credentials are sent only to the exact issuer origin and redirects fail closed. A failed workload admission produces recoverable unavailability. For Vercel Preview Trusted Sources, the consumer can return a fresh `x-vercel-trusted-oidc-idp-token` from the maintained Vercel OIDC helper. The actual project/environment trust rule must be configured separately.

Consumer sign-in begins at `/api/auth/federation/start`; its registered callback is `/api/auth/federation/callback`. Local sign-out removes one app session. Signing out the central browser session invalidates its connected grants. Recovery invalidates all old credential epochs. Issuer unavailability throws `AuthenticationUnavailableError` on protected reads; show a retry state instead of treating this as a missing account. No refresh grants, automatic email linking or existing-account migration is included.

An app session lasts at most one hour, the access-token lifetime. Every protected read still re-checks the live central session, so logout and recovery take effect immediately. When `getPrincipal` returns null, send the browser back through `/api/auth/federation/start` with the current path. While the central session is alive, the issuer returns without another credential prompt. Keep unsaved form input across that round trip.

On Vercel, pass `ipAddress: { headers: ["x-vercel-forwarded-for"] }` so rate limits can key requests. Without trusted IP headers, the maintained rate limiter cannot attribute requests to a client.

Phone approval in central mode signs the requesting browser in to the whole central account, not one app. The approval screen says so. Scoping an approved browser to one app is a follow-up.

## Email sign-in codes

Standalone and issuer modes opt in only when their email adapter supplies `sendSignInCode`. The maintained browser plugin exposes `emailOtp.sendVerificationOtp({email,type:"sign-in"})` and `signIn.emailOtp({email,otp})`. Normalize surrounding whitespace before submission. Codes have six digits, a ten-minute lifetime and three attempts. Only an existing verified account is eligible; unknown and unverified destinations receive the same successful request response without delivery. Resends advance an atomic generation, and recovery invalidates outstanding codes. Enrolled MFA still follows email-code sign-in.

The shared screens in `@royer/auth-ui` require explicit `emailCodeEnabled`; the standalone reference defaults to disabled. This UI package currently ships as a private monorepo workspace. Do not assume an auth tarball contains its source.

## Browser

```ts
import { createPrivateAuthClient, createCompanionClient } from "@royer/auth/client";

export const authClient = createPrivateAuthClient();
export const companion = createCompanionClient();
```

For a custom issuer UI, use `createIdentityAuthClient` instead of `createPrivateAuthClient`. It includes the maintained provider client that carries signed authorization through credential and MFA requests. Preserve the complete signed query unchanged across signup, sign-in and second-factor navigation. Handle the second-factor continuation first, then a successful provider response `{redirect:true,url}`; follow that server-provided continuation, rejecting non-HTTP(S) addresses or URLs containing credentials. It may point to the registered consumer callback. Do not reconstruct signatures or redirect directly to a caller-supplied callback. The shared hosted screens implement this flow.

For provider-bound phone approval, start with `companion.start({oauthQuery: window.location.search})` while the signed authorization query is present. Show the returned registered app name. After approved polling, follow the server-returned HTTP(S) `redirectURL`, rejecting credentials in the URL. It may complete at the registered consumer callback or return to issuer reauthentication; it must not come from browser query parameters. A direct account-login request omits `oauthQuery` and need not return a redirect. Omitting the signed query during an app login loses that app continuation.

The client entrypoint requires React 19; server-only consumers do not. Both factories default to the current origin. An explicit baseURL must be the same application origin in browser deployments.

The maintained SDK exposes `signUp.email({name,email,password,username})`, `signIn.email`, `signIn.username`, password recovery, `passkey.addPasskey`, `signIn.passkey`, `twoFactor.enable`, `twoFactor.verifyTotp`, `twoFactor.verifyBackupCode` and `signOut`. Username is optional at signup; email remains required for verification and recovery. Use the installed SDK's declared inputs rather than copying request shapes.

Password sign-in requires verified email. Passwords are 15–128 characters with no composition rule. TOTP must be confirmed before enrollment is active; enrolled accounts must finish a TOTP or one-use backup-code challenge on password login. Passkeys require authenticator user verification and serve as a strong alternative. A device PIN may satisfy user verification; the server cannot promise a biometric was used. Phone approval inherits the approving session's assurance and original authentication age (including repeated approval chains), so a password-only approval cannot bypass later TOTP enrollment. Remembered second-factor devices are disabled. Each authenticator code can succeed once per enrolled factor across server instances. The maintained verifier accepts its default adjacent time windows; successful codes have a keyed, database-unique replay record retained for 90 seconds and removed lazily after expiry. Failed validation creates no record. A replay or replay-store failure never returns a newly created live session; an existing authenticated session is preserved. After a replay rejection during login, begin sign-in again with the next code.

## Phone approval

`companion.start()` returns `{userCode,verificationUri,expiresAt,interval}`: expiry is Unix milliseconds and interval is seconds. Display the public verification URI as a QR code and offer the eight-character code for manual entry. Do not construct or store a device credential. The browser receives the private credential only as an HttpOnly, SameSite=Strict cookie.

On the phone, require sign-in, call `companion.details(userCode)` for `{userCode,appName,expiresAt}`, and show the app and code before an explicit decision. Call `companion.decide({userCode,decision:"approve"|"deny"})`. The requesting browser calls `companion.poll()` at the returned interval until `status` is approved, denied or expired. A `slow_down` result includes `retryAfterSeconds`; increase the polling interval by at least five seconds and keep the larger of that increase and the server delay for all subsequent polls. The server persists each five-second increase across callers. The UI owns timing, cancellation, retry and offline messages.

These methods use only `/api/auth/companion/start`, `/poll`, `/request`, `/approve`, and `/deny`. Start/poll/decisions are POST with exact Origin required. Grants expire after five minutes, are bound to the requester browser and app, and are consumed atomically once. The approving session must remain valid during redemption. Public upstream device routes are blocked; session bearer tokens are removed from JSON responses. Individual session-token revocation methods are therefore not a browser contract; sign-out and revoke-other-sessions remain supported.

## Recovery and operations

Password reset revokes sessions, outstanding approved grants and unfinished second-factor proofs. A credential epoch checked after the vendor's hooks prevents an old-password challenge from being created after reset cleanup. A reset does not remove enrolled passkeys or TOTP: email recovery alone must not remove a second factor. Losing all second factors needs a separate recovery policy; this candidate does not offer an administrator bypass.

Database-backed IP limits accompany shared account/destination limits: 12 password attempts and five recovery/verification delivery requests per 15-minute bucket. Email and username currently have separate identifier buckets; IP limits remain in addition. No forwarding headers are trusted by default: unresolved clients share a conservative IP bucket. Configure `ipAddress.headers` only for authoritative headers overwritten by your ingress; optional `trustedProxies` accepts explicit IPs or CIDR ranges and resolves chains from the rightmost untrusted hop. The Request interface cannot attest the network peer: prevent direct access around that ingress and strip user-supplied header copies there. With no trusted proxies, only a single-value IP header is accepted. Additional unconfigured headers are ignored. Monitor abuse and establish database retention/cleanup for expired auth and rate-limit records. This is a baseline, not a global fraud service.

Cookies are app-prefixed, host-only, HttpOnly and secure under HTTPS. Cookie caching is disabled, so revocation is checked in the database. Passkey enrollment and removal require a session created within the last ten minutes. The reference app offers sign-out and fresh sign-in when removal requires reauthentication. Native apps, embedded webviews, arbitrary cross-origin credential clients, enterprise federation, organizations and tenant authorization remain outside this increment. Central web sign-in uses the separate OIDC adapter above.

Keep `Principal.id` as the application's stable foreign key. If adopting a provider later, map its verified issuer+subject to the existing local principal in an explicit migration; do not equate accounts by an unverified email. Shared package code does not mean shared user storage.

## Verification and updates

Run `npm test --workspace @royer/auth` from the repository root. Tests exercise public Request handlers against a real migrated SQLite database, cookie jars, reset and TOTP recovery, one-use concurrent phone approval, expiry, rejection and account limits. The emitted TypeScript declarations have a consumer compilation test. The opt-in PostgreSQL suite repeats cross-instance account-limit, reset, TOTP and phone-redemption checks. It requires an empty loopback database on port 5448 named `royer_auth_test_*`, supplied through `ROYER_AUTH_TEST_POSTGRES_URL`; CI creates this disposable fixture. Browser WebAuthn testing belongs to the reference app.

`npm pack` builds the package first. Keep Better Auth and its passkey plugin on matching reviewed versions, rerun the handler and browser suites after updates, and assess upstream advisories. This is a private release candidate, not a production audit certification.
